{{ config(
    tags=["stage"]
) }}
{%- set yaml_metadata -%}
source_model: wms_raw_cartographie
hashed_columns:
  EMPLACEMENT_SITE_HK: 
    - CODE_SITE
    - ID_EMPLACEMENT
    - CODE_SITE
  EMPLACEMENT_SAT_HDIFF:
    is_hashdiff: true
    columns:
      - CODE_SITE
      - ID_EMPLACEMENT
      - code_epc
      - libl_epc
      - type_taille_epc
      - libl_lgr_epc
      - libl_lrg_epc
      - libl_htr_epc
      - code_blocage
      - libl_region
      - libl_type_epc
      - libl_zone_rgt
      - libl_zone_prl
derived_columns:
  RSRC: RECORD_SOURCE
  LDTS: LOAD_DATE
  EFFECTIVE_FROM: LOAD_DATE
  SITE_NK: CODE_SITE
  EMPLACEMENT_NK: 
    - CODE_SITE
    - ID_EMPLACEMENT
{%- endset -%}

{% set metadata_dict = fromyaml(yaml_metadata) %}

{% set source_model = metadata_dict["source_model"] %}
{% set derived_columns = metadata_dict["derived_columns"] %}
{% set null_columns = metadata_dict["null_columns"] %}
{% set hashed_columns = metadata_dict["hashed_columns"] %}
{% set ranked_columns = metadata_dict["ranked_columns"] %}

{{ automate_dv.stage(include_source_columns=true,
                     source_model=source_model,
                     derived_columns=derived_columns,
                     null_columns=null_columns,
                     hashed_columns=hashed_columns,
                     ranked_columns=none) }}