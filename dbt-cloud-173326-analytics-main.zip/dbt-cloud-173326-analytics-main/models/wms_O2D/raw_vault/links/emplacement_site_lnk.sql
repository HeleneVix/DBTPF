{{ config(
    tags=["link","raw_vault"],materialized='incremental'
) }}

{%- set yaml_metadata -%}
source_model: wms_stg_cartographie
src_pk: EMPLACEMENT_SITE_HK
src_fk: 
  - SITE_NK
  - EMPLACEMENT_NK
src_ldts: LDTS
src_source: RSRC
{%- endset -%}

{% set metadata_dict = fromyaml(yaml_metadata) %}

{{ automate_dv.link(src_pk=metadata_dict["src_pk"],
                    src_fk=metadata_dict["src_fk"], 
                    src_ldts=metadata_dict["src_ldts"],
                    src_source=metadata_dict["src_source"], 
                    source_model=metadata_dict["source_model"]) }}