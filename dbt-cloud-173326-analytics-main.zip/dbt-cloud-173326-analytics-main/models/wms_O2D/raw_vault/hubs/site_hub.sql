{{ config(
    tags=["hub","raw_vault"],materialized='incremental'
) }}

{%- set yaml_metadata -%}
source_model: wms_stg_cartographie
src_pk: SITE_NK
src_nk: CODE_SITE
src_ldts: LDTS
src_source: RSRC
{%- endset -%}

{% set metadata_dict = fromyaml(yaml_metadata) %}

{{ automate_dv.hub(src_pk=metadata_dict["src_pk"],
                   src_nk=metadata_dict["src_nk"], 
                   src_ldts=metadata_dict["src_ldts"],
                   src_source=metadata_dict["src_source"],
                   source_model=metadata_dict["source_model"]) }}