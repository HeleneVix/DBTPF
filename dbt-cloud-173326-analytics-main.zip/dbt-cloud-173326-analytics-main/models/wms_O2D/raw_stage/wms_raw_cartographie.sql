{{ config(
    tags=["raw"]
) }}
select
    a.code_entrepot as code_site,
    a.id_empl as id_emplacement,
    a.code_empl as code_epc,
    a.lib_empl as libl_epc,
    a.type_tail_empl as type_taille_epc,
    a.long_empl as libl_lgr_epc,
    a.larg_empl as libl_lrg_epc,
    a.haut_empl as libl_htr_epc,
    a.bloc_empl as code_blocage,
    a.reg_phy_lm7 as libl_region,
    a.lib_type_empl as libl_type_epc,
    a.zone_rang as libl_zone_rgt,
    a.zone_prelev as libl_zone_prl,
    a.source as record_source,
    a.date_integration as load_date
from {{ source("psa_wms", "CARTOGRAPHIE") }} as a
